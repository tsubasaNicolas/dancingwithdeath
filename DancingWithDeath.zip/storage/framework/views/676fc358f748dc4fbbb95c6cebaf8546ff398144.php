<?php $__env->startSection('template_title'); ?>
    <?php echo e($appointment->name ?? 'Show Appointment'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="float-left">
                            <span class="card-title">Show Appointment</span>
                        </div>
                        <div class="float-right">
                            <a class="btn btn-primary" href="<?php echo e(route('appointments.index')); ?>"> Back</a>
                        </div>
                    </div>

                    <div class="card-body">
                        
                        <div class="form-group">
                            <strong>Name:</strong>
                            <?php echo e($appointment->name); ?>

                        </div>
                        <div class="form-group">
                            <strong>Email:</strong>
                            <?php echo e($appointment->email); ?>

                        </div>
                        <div class="form-group">
                            <strong>Starttime:</strong>
                            <?php echo e($appointment->startTime); ?>

                        </div>
                        <div class="form-group">
                            <strong>Endtime:</strong>
                            <?php echo e($appointment->endTime); ?>

                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\DancingWithDeath\resources\views/appointment/show.blade.php ENDPATH**/ ?>